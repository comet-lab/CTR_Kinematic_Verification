var searchData=
[
  ['initialize',['Initialize',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a2855ad05a97fcc086a90a61ab732a018',1,'NDI.CapiSample.Protocol.Capi.Initialize()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#a4d39155c41765bc184e94a52c603945e',1,'NDI.CapiSample.Protocol.Port.Initialize()'],['../classNDI_1_1CapiSample_1_1Utility_1_1CRC.html#a4aa54e6953219b179962cbde3bf1982e',1,'NDI.CapiSample.Utility.CRC.Initialize()']]],
  ['initializeports',['InitializePorts',['../classNDI_1_1CapiSampleApplication_1_1Program.html#aaae722649881e620b396ef72f08021eb',1,'NDI.CapiSampleApplication.Program.InitializePorts()'],['../classNDI_1_1CapiSampleStreaming_1_1Program.html#a50c3e46ec311e18a8ddb1e5c2cdbf41d',1,'NDI.CapiSampleStreaming.Program.InitializePorts()']]],
  ['isbx2supported',['IsBX2Supported',['../classNDI_1_1CapiSampleApplication_1_1Program.html#a01885e7d3da37a72c18a175b053a137f',1,'NDI::CapiSampleApplication::Program']]],
  ['issupported',['IsSupported',['../classNDI_1_1CapiSampleStreaming_1_1Program.html#a286a053a0bf10695499abf018c5456a4',1,'NDI::CapiSampleStreaming::Program']]]
];
