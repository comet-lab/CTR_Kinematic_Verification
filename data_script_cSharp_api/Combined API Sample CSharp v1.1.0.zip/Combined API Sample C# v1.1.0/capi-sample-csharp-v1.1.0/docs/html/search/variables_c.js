var searchData=
[
  ['number',['number',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a117e2ed4de1a89bc330667b684295a98',1,'NDI::CapiSample::Protocol::GBF::GbfFrameItem']]]
];
