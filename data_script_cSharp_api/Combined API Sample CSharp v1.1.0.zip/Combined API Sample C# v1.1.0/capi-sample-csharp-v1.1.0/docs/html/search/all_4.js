var searchData=
[
  ['data',['data',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrame.html#ae5d315c82f97c2237526af6e3fc8bf7f',1,'NDI.CapiSample.Protocol.GBF.GbfFrame.data()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a750ab5834b437dfed04a7e22947529f4',1,'NDI.CapiSample.Protocol.GBF.GbfFrameItem.data()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1AsciiPacket.html#a8c60b84db624615736d492223e5e4afe',1,'NDI.CapiSample.Protocol.AsciiPacket.Data()']]],
  ['data2d',['Data2D',['../namespaceNDI_1_1CapiSample_1_1Protocol_1_1GBF.html#a055834992c2b0d090e216654bf2919dea5a509c2245b5389cd6585effd507d0b0',1,'NDI::CapiSample::Protocol::GBF']]],
  ['data3d',['Data3D',['../namespaceNDI_1_1CapiSample_1_1Protocol_1_1GBF.html#a055834992c2b0d090e216654bf2919dea77934ac653c7bbf13b0330bf611d29d2',1,'NDI::CapiSample::Protocol::GBF']]],
  ['data6d',['Data6D',['../namespaceNDI_1_1CapiSample_1_1Protocol_1_1GBF.html#a055834992c2b0d090e216654bf2919deae9a7f2e7231907433777657eb8f10bfd',1,'NDI::CapiSample::Protocol::GBF']]],
  ['databufferlimit',['DataBufferLimit',['../namespaceNDI_1_1CapiSample_1_1Data.html#a673f8d4be756b5c1dc4603c5ffd4818ba39aea5882ac1cf8efb55555e88d6b456',1,'NDI::CapiSample::Data']]],
  ['dataisnew',['dataIsNew',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a7d7c81ac0b576aaadf3d858e57a0c30a',1,'NDI::CapiSample::Data::Tool']]],
  ['degreesoffreedom',['DegreesOfFreedom',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#ad4195c4bd828a8d4e6d54f91f939bb1d',1,'NDI.CapiSample.Protocol.Port.DegreesOfFreedom()'],['../namespaceNDI_1_1CapiSample_1_1Protocol.html#acabd1db1cf3bbd0f57f2d24443b2c40b',1,'NDI.CapiSample.Protocol.DegreesOfFreedom()']]],
  ['disabled',['Disabled',['../namespaceNDI_1_1CapiSample_1_1Data.html#a5fe0a5f9b693183ed5c9ca75101d9d2cab9f5c797ebbf55adccdd8539a65a0241',1,'NDI::CapiSample::Data']]],
  ['disconnect',['Disconnect',['../classNDI_1_1CapiSample_1_1CapiSerial.html#a356550938a13bc98b67bff42c4ac45c1',1,'NDI.CapiSample.CapiSerial.Disconnect()'],['../classNDI_1_1CapiSample_1_1CapiTcp.html#ae1c7d354b37227d32b5f95d7cd8c89c5',1,'NDI.CapiSample.CapiTcp.Disconnect()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a1cef18edad0c5268c718e3cedbcbf716',1,'NDI.CapiSample.Protocol.Capi.Disconnect()']]],
  ['dummy',['Dummy',['../namespaceNDI_1_1CapiSample_1_1Data.html#a10c84fdce96b5c4483eba82349bd7503abcf036b6f33e182d4705f4f5b1af13ac',1,'NDI::CapiSample::Data']]]
];
