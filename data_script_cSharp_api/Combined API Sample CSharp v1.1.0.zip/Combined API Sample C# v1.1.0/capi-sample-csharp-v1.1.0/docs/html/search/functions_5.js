var searchData=
[
  ['flush',['Flush',['../classNDI_1_1CapiSample_1_1Utility_1_1SeekableBufferedStream.html#aabbbdbe22d611d86b5f724891a6a296f',1,'NDI::CapiSample::Utility::SeekableBufferedStream']]],
  ['free',['Free',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#aa8582620e98f2e8bc4afd3c23709b377',1,'NDI::CapiSample::Protocol::Port']]]
];
