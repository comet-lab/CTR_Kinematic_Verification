var searchData=
[
  ['tool',['Tool',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html',1,'NDI::CapiSample::Data']]],
  ['transform',['Transform',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html',1,'NDI::CapiSample::Data']]]
];
