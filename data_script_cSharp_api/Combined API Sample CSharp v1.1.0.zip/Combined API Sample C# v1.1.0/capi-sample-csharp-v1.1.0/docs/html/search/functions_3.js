var searchData=
[
  ['disconnect',['Disconnect',['../classNDI_1_1CapiSample_1_1CapiSerial.html#a356550938a13bc98b67bff42c4ac45c1',1,'NDI.CapiSample.CapiSerial.Disconnect()'],['../classNDI_1_1CapiSample_1_1CapiTcp.html#ae1c7d354b37227d32b5f95d7cd8c89c5',1,'NDI.CapiSample.CapiTcp.Disconnect()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a1cef18edad0c5268c718e3cedbcbf716',1,'NDI.CapiSample.Protocol.Capi.Disconnect()']]]
];
