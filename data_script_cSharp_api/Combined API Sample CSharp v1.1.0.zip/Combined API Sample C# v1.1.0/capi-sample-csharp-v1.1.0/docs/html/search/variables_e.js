var searchData=
[
  ['portstatus',['portStatus',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a0fc87b2753c48876d42e9178bd9a03d6',1,'NDI::CapiSample::Data::Tool']]],
  ['position',['position',['../classNDI_1_1CapiSample_1_1Data_1_1Marker.html#a7db25cdcf5dfd4eca8e07907ee6825a3',1,'NDI.CapiSample.Data.Marker.position()'],['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#aba8770e615764677d153c8d1b1adb6d4',1,'NDI.CapiSample.Data.Transform.position()']]]
];
