var searchData=
[
  ['listeners',['Listeners',['../classNDI_1_1CapiSample_1_1Protocol_1_1StreamCommand.html#a4d05a5f8a571d4210da78f574c2b01bd',1,'NDI::CapiSample::Protocol::StreamCommand']]],
  ['logtransit',['LogTransit',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#ad44d2a82b1208664a0aa85e530a2005c',1,'NDI::CapiSample::Protocol::Capi']]]
];
