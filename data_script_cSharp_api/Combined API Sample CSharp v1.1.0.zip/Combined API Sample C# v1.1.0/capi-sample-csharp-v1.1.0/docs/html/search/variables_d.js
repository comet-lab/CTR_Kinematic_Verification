var searchData=
[
  ['orientation',['orientation',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#a6e008b41ea5137906d638d9570ce26c7',1,'NDI::CapiSample::Data::Transform']]]
];
