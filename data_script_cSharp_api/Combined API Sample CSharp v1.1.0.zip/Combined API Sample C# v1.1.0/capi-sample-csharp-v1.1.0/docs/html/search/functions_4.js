var searchData=
[
  ['enable',['Enable',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#a7db5ea535a923012559bb9b836c7661b',1,'NDI::CapiSample::Protocol::Port']]]
];
