var searchData=
[
  ['error',['error',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#adfde0585b214b890681f305fa6bf35f6',1,'NDI::CapiSample::Data::Transform']]]
];
