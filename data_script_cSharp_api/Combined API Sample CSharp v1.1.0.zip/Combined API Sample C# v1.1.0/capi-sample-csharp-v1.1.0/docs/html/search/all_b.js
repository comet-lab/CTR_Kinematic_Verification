var searchData=
[
  ['magnetic',['Magnetic',['../namespaceNDI_1_1CapiSample_1_1Data.html#a10c84fdce96b5c4483eba82349bd7503a52432cbd9f9df2483189ce2cb45f8bad',1,'NDI::CapiSample::Data']]],
  ['main',['Main',['../classNDI_1_1CapiSampleApplication_1_1Program.html#aafb1ba09de0d683f03ff25f718bc1594',1,'NDI.CapiSampleApplication.Program.Main()'],['../classNDI_1_1CapiSampleStreaming_1_1Program.html#a44264f61c146fd1b452550fc9f306d9a',1,'NDI.CapiSampleStreaming.Program.Main()']]],
  ['maintemp',['MainTemp',['../namespaceNDI_1_1CapiSample_1_1Data.html#a096caf66cb8f24696213967ea5e3797fafb12894fdee16b645036befac9a88eb5',1,'NDI::CapiSample::Data']]],
  ['mainvoltage',['MainVoltage',['../namespaceNDI_1_1CapiSample_1_1Data.html#a096caf66cb8f24696213967ea5e3797fabf7e2366207d7808e0cad8e60ccf58d2',1,'NDI::CapiSample::Data']]],
  ['manufacturer',['Manufacturer',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#a5f6c180eec6b263514ce9eb861859a06',1,'NDI::CapiSample::Protocol::Port']]],
  ['marker',['Marker',['../classNDI_1_1CapiSample_1_1Data_1_1Marker.html',1,'NDI::CapiSample::Data']]],
  ['marker_2ecs',['Marker.cs',['../Marker_8cs.html',1,'']]],
  ['markers',['markers',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a0a2d2b0c2f543351c32f32cc8c31654b',1,'NDI.CapiSample.Data.Tool.markers()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfData3D.html#a123af9e21ba758ddcf5d43ae51cb8b90',1,'NDI.CapiSample.Protocol.GBF.GbfData3D.markers()']]],
  ['markerstatus',['MarkerStatus',['../namespaceNDI_1_1CapiSample_1_1Data.html#a5bdd244c85df22cbcd881d942471a595',1,'NDI::CapiSample::Data']]],
  ['microscopetracker',['MicroscopeTracker',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#ac183d1ac572059b4170e9d113cdfb1d5af852e46cd1795c26100147019d6dd74c',1,'NDI::CapiSample::Protocol']]],
  ['missing',['Missing',['../namespaceNDI_1_1CapiSample_1_1Data.html#a5bdd244c85df22cbcd881d942471a595a2aee0be2678ee90fd327cc186826438e',1,'NDI.CapiSample.Data.Missing()'],['../namespaceNDI_1_1CapiSample_1_1Data.html#a5fe0a5f9b693183ed5c9ca75101d9d2ca2aee0be2678ee90fd327cc186826438e',1,'NDI.CapiSample.Data.Missing()']]]
];
