var searchData=
[
  ['manufacturer',['Manufacturer',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#a5f6c180eec6b263514ce9eb861859a06',1,'NDI::CapiSample::Protocol::Port']]]
];
