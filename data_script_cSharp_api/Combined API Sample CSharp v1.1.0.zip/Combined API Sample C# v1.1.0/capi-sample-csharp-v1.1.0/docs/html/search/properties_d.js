var searchData=
[
  ['tooltype',['ToolType',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#ab1fe25a16e6617acb3272e41f26d7b2a',1,'NDI::CapiSample::Protocol::Port']]]
];
