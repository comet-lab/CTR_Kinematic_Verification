var searchData=
[
  ['active',['Active',['../namespaceNDI_1_1CapiSample_1_1Data.html#a10c84fdce96b5c4483eba82349bd7503a4d3d769b812b6faa6b76e1a8abaece2d',1,'NDI::CapiSample::Data']]],
  ['activewireless',['ActiveWireless',['../namespaceNDI_1_1CapiSample_1_1Data.html#a10c84fdce96b5c4483eba82349bd7503abe52a20cfaed3aa8f26b2763641ddacf',1,'NDI::CapiSample::Data']]],
  ['alert',['Alert',['../namespaceNDI_1_1CapiSample_1_1Data.html#a7f89ff5430b16c54780c655ae2c04983ab92071d61c88498171928745ca53078b',1,'NDI::CapiSample::Data']]],
  ['algorithmlimit',['AlgorithmLimit',['../namespaceNDI_1_1CapiSample_1_1Data.html#a673f8d4be756b5c1dc4603c5ffd4818ba549977ff2175d808e169f1d2052da465',1,'NDI::CapiSample::Data']]],
  ['all',['All',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#a74c1492033e40fd4b884f034cfd91740ab1c94ca2fbc3e78fc30069c8d0f01680',1,'NDI::CapiSample::Protocol']]],
  ['alltransforms',['AllTransforms',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#ab301a755f600f4b3065543d30fd61ff7a1ab3f9215ae1f9e23c3026ebabcf0ddc',1,'NDI::CapiSample::Protocol']]]
];
