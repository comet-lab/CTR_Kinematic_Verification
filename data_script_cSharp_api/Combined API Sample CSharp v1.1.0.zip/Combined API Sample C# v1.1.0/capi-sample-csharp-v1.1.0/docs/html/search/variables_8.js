var searchData=
[
  ['handlestatus',['handleStatus',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a6eecf9e37b760987549fbe6d377c488d',1,'NDI::CapiSample::Data::Tool']]]
];
