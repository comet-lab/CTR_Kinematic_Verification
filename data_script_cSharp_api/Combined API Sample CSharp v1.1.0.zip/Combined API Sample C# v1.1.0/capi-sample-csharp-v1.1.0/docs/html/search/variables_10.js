var searchData=
[
  ['rawstatus',['rawStatus',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#a8b3f180a2885104110f30f80a2d626f9',1,'NDI::CapiSample::Data::Transform']]]
];
