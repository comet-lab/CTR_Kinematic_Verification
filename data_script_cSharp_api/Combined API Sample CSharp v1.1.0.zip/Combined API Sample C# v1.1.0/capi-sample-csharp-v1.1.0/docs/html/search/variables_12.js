var searchData=
[
  ['timespec_5fns',['timespec_ns',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a94f90bfb55a5a0cb4311c4bf0ecb82ad',1,'NDI.CapiSample.Data.Tool.timespec_ns()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a85fc6406492ee3f7b3e9c43c516efa1c',1,'NDI.CapiSample.Protocol.GBF.GbfFrameItem.timespec_ns()']]],
  ['timespec_5fs',['timespec_s',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#aa952e100eea2a431f81b15bd5476117f',1,'NDI.CapiSample.Data.Tool.timespec_s()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a6f9bd35169549ff0bf7889dc41358fd2',1,'NDI.CapiSample.Protocol.GBF.GbfFrameItem.timespec_s()']]],
  ['toolhandle',['toolHandle',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#a79772975595efb72fe942596503aa236',1,'NDI::CapiSample::Data::Transform']]],
  ['toolinfo',['toolInfo',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#ac177391b5f405af9dae183c2bbd8426e',1,'NDI::CapiSample::Data::Tool']]],
  ['tools',['tools',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfData6D.html#ad4b190b70e78a092922abd4bb4398746',1,'NDI::CapiSample::Protocol::GBF::GbfData6D']]],
  ['transform',['transform',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a47f61ceadb8ebab535e191cfb2819360',1,'NDI::CapiSample::Data::Tool']]],
  ['type',['type',['../classNDI_1_1CapiSample_1_1Data_1_1SystemAlert.html#a480e792e028f746341bb848f05ba2e3b',1,'NDI.CapiSample.Data.SystemAlert.type()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfComponent.html#ab6de2d70684a060c3b0ba728c38553bc',1,'NDI.CapiSample.Protocol.GBF.GbfComponent.type()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a7c6970a4a6b3efee31ec69b841d4d614',1,'NDI.CapiSample.Protocol.GBF.GbfFrameItem.type()']]]
];
