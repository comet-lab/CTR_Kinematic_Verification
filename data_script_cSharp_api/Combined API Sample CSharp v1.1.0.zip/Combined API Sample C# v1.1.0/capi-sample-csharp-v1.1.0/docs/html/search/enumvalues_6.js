var searchData=
[
  ['gpiolines',['GPIOLines',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#ab6a2f541f81a8d82d827a84d66262de9a178b647c207d528f1e8ea576a3fbddeb',1,'NDI::CapiSample::Protocol']]]
];
