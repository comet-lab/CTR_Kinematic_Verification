var searchData=
[
  ['data',['Data',['../classNDI_1_1CapiSample_1_1Protocol_1_1AsciiPacket.html#a8c60b84db624615736d492223e5e4afe',1,'NDI::CapiSample::Protocol::AsciiPacket']]],
  ['degreesoffreedom',['DegreesOfFreedom',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#ad4195c4bd828a8d4e6d54f91f939bb1d',1,'NDI::CapiSample::Protocol::Port']]]
];
