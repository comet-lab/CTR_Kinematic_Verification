var searchData=
[
  ['index',['index',['../classNDI_1_1CapiSample_1_1Data_1_1Marker.html#a432d2549b5df1d9b4434644a0f03a7ad',1,'NDI::CapiSample::Data::Marker']]],
  ['ismissing',['isMissing',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#a9698d61d40badd62104b3f303f9a0582',1,'NDI::CapiSample::Data::Transform']]],
  ['itemcount',['itemCount',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfComponent.html#a0827afcc09a366589c75876fcb470469',1,'NDI::CapiSample::Protocol::GBF::GbfComponent']]],
  ['itemformatoption',['itemFormatOption',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfComponent.html#a73b0e35fa0f3678f8193a39a1b74d7b0',1,'NDI::CapiSample::Protocol::GBF::GbfComponent']]]
];
