var searchData=
[
  ['quaternion',['Quaternion',['../classNDI_1_1CapiSample_1_1Data_1_1Quaternion.html#a6664a33a9e28f2fe2edf2bfb0e0bc791',1,'NDI.CapiSample.Data.Quaternion.Quaternion()'],['../classNDI_1_1CapiSample_1_1Data_1_1Quaternion.html#a67eb55f963773b7ba5943c63a8a413f3',1,'NDI.CapiSample.Data.Quaternion.Quaternion(double q0, double qx, double qy, double qz)']]]
];
