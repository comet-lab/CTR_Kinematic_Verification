var searchData=
[
  ['data',['data',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrame.html#ae5d315c82f97c2237526af6e3fc8bf7f',1,'NDI.CapiSample.Protocol.GBF.GbfFrame.data()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a750ab5834b437dfed04a7e22947529f4',1,'NDI.CapiSample.Protocol.GBF.GbfFrameItem.data()']]],
  ['dataisnew',['dataIsNew',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a7d7c81ac0b576aaadf3d858e57a0c30a',1,'NDI::CapiSample::Data::Tool']]]
];
