var searchData=
[
  ['q0',['q0',['../classNDI_1_1CapiSample_1_1Data_1_1Quaternion.html#a24d2a95ca9476107e0eda41e2fbf9988',1,'NDI::CapiSample::Data::Quaternion']]],
  ['quaternion',['Quaternion',['../classNDI_1_1CapiSample_1_1Data_1_1Quaternion.html#a6664a33a9e28f2fe2edf2bfb0e0bc791',1,'NDI.CapiSample.Data.Quaternion.Quaternion()'],['../classNDI_1_1CapiSample_1_1Data_1_1Quaternion.html#a67eb55f963773b7ba5943c63a8a413f3',1,'NDI.CapiSample.Data.Quaternion.Quaternion(double q0, double qx, double qy, double qz)']]],
  ['quaternion',['Quaternion',['../classNDI_1_1CapiSample_1_1Data_1_1Quaternion.html',1,'NDI::CapiSample::Data']]],
  ['quaternion_2ecs',['Quaternion.cs',['../Quaternion_8cs.html',1,'']]],
  ['qx',['qx',['../classNDI_1_1CapiSample_1_1Data_1_1Quaternion.html#adf3952cf523d23d64f8cc61f79eede2d',1,'NDI::CapiSample::Data::Quaternion']]],
  ['qy',['qy',['../classNDI_1_1CapiSample_1_1Data_1_1Quaternion.html#a2d08de149ba5cd8bed59e25d6adbf8bf',1,'NDI::CapiSample::Data::Quaternion']]],
  ['qz',['qz',['../classNDI_1_1CapiSample_1_1Data_1_1Quaternion.html#a7c7a1246a151a184af9d008f6d3c4f3e',1,'NDI::CapiSample::Data::Quaternion']]]
];
