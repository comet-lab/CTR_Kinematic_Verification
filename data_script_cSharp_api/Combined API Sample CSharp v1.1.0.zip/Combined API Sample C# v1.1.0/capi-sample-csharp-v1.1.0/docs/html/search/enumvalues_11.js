var searchData=
[
  ['valid',['Valid',['../namespaceNDI_1_1CapiSample_1_1Data.html#a5fe0a5f9b693183ed5c9ca75101d9d2ca3ac705f2acd51a4613f9188c05c91d0d',1,'NDI::CapiSample::Data']]]
];
