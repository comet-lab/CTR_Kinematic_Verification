var searchData=
[
  ['bytes',['Bytes',['../classNDI_1_1CapiSample_1_1Protocol_1_1Packet.html#afbd9c9fde84717c8d3db7dbd2f429f24',1,'NDI::CapiSample::Protocol::Packet']]]
];
