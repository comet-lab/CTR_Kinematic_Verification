var searchData=
[
  ['componenttype',['ComponentType',['../namespaceNDI_1_1CapiSample_1_1Protocol_1_1GBF.html#a055834992c2b0d090e216654bf2919de',1,'NDI::CapiSample::Protocol::GBF']]]
];
