var searchData=
[
  ['transformstatus',['TransformStatus',['../namespaceNDI_1_1CapiSample_1_1Data.html#a673f8d4be756b5c1dc4603c5ffd4818b',1,'NDI::CapiSample::Data']]]
];
