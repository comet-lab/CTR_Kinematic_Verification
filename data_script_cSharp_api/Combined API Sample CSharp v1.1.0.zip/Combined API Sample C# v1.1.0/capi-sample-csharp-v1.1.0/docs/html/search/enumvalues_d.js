var searchData=
[
  ['reference',['Reference',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#ac183d1ac572059b4170e9d113cdfb1d5a63d5049791d9d79d86e9a108b0a999ca',1,'NDI::CapiSample::Protocol']]]
];
