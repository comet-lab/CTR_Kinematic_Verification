var searchData=
[
  ['vector3',['Vector3',['../classNDI_1_1CapiSample_1_1Data_1_1Vector3.html#a2d8087cb408092c620b80d95e4be2fb3',1,'NDI.CapiSample.Data.Vector3.Vector3()'],['../classNDI_1_1CapiSample_1_1Data_1_1Vector3.html#a9991cd512893917ecc7ccf68e15f898a',1,'NDI.CapiSample.Data.Vector3.Vector3(double x, double y, double z)']]]
];
