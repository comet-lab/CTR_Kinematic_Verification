var searchData=
[
  ['alerts',['alerts',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfSystemAlert.html#a1b97bbf76b0263e1354b610fdcf5d722',1,'NDI::CapiSample::Protocol::GBF::GbfSystemAlert']]]
];
