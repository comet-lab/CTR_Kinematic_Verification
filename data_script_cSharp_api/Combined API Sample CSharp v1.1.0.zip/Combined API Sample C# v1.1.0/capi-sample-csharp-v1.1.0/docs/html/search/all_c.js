var searchData=
[
  ['capisample',['CapiSample',['../namespaceNDI_1_1CapiSample.html',1,'NDI']]],
  ['capisampleapplication',['CapiSampleApplication',['../namespaceNDI_1_1CapiSampleApplication.html',1,'NDI']]],
  ['capisamplestreaming',['CapiSampleStreaming',['../namespaceNDI_1_1CapiSampleStreaming.html',1,'NDI']]],
  ['data',['Data',['../namespaceNDI_1_1CapiSample_1_1Data.html',1,'NDI::CapiSample']]],
  ['gbf',['GBF',['../namespaceNDI_1_1CapiSample_1_1Protocol_1_1GBF.html',1,'NDI::CapiSample::Protocol']]],
  ['ndi',['NDI',['../namespaceNDI.html',1,'']]],
  ['nonfatalparameter',['NonFatalParameter',['../namespaceNDI_1_1CapiSample_1_1Data.html#ad8397722b3cff95bce3f02774bc5622eaddc22e688c5c4342a091abbdb165e361',1,'NDI::CapiSample::Data']]],
  ['notenabled',['NotEnabled',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#a74c1492033e40fd4b884f034cfd91740a382542b455122ca37f377b7a66cafc4d',1,'NDI::CapiSample::Protocol']]],
  ['notinit',['NotInit',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#a74c1492033e40fd4b884f034cfd91740a46dbb2fe48fe1beb6a7f2893c6ae56e5',1,'NDI::CapiSample::Protocol']]],
  ['number',['number',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a117e2ed4de1a89bc330667b684295a98',1,'NDI::CapiSample::Protocol::GBF::GbfFrameItem']]],
  ['numberofsensors',['NumberOfSensors',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#a8db4bd012a936472c0665790e144dcb7',1,'NDI::CapiSample::Protocol::Port']]],
  ['protocol',['Protocol',['../namespaceNDI_1_1CapiSample_1_1Protocol.html',1,'NDI::CapiSample']]],
  ['utility',['Utility',['../namespaceNDI_1_1CapiSample_1_1Utility.html',1,'NDI::CapiSample']]]
];
