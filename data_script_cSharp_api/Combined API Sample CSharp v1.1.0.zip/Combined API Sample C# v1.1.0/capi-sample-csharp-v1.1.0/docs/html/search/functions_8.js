var searchData=
[
  ['listen',['Listen',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a3e0a514a71e46efab1c3d0af4a9225bf',1,'NDI::CapiSample::Protocol::Capi']]],
  ['loadsrom',['LoadSROM',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#ad5acaee199566aacdaf6a37486173080',1,'NDI::CapiSample::Protocol::Port']]],
  ['log',['log',['../classNDI_1_1CapiSampleApplication_1_1Program.html#a04e3cd2974e7d4da66623dfcb3fe3407',1,'NDI.CapiSampleApplication.Program.log()'],['../classNDI_1_1CapiSampleStreaming_1_1Program.html#afa438b5a26489016c8cc26bdf2ceca11',1,'NDI.CapiSampleStreaming.Program.log()']]],
  ['logger',['Logger',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#a6d7346f1d60647f9434c2a9db56cce0a',1,'NDI::CapiSample::Protocol']]]
];
