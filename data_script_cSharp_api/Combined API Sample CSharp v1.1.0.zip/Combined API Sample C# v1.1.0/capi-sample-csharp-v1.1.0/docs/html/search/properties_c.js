var searchData=
[
  ['serialnumber',['SerialNumber',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#a8161ce716bff03e7b223ff85bfecd5e7',1,'NDI::CapiSample::Protocol::Port']]],
  ['startsequence',['StartSequence',['../classNDI_1_1CapiSample_1_1Protocol_1_1BinaryPacket.html#ab3b3cb5c9e439854c5320bbdae63a6f4',1,'NDI.CapiSample.Protocol.BinaryPacket.StartSequence()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1StreamPacket.html#a04031e5951dc9d2a2a4ea7409f65500b',1,'NDI.CapiSample.Protocol.StreamPacket.StartSequence()']]],
  ['status',['Status',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#a627fc2d7915a87db9244765bdd1cc449',1,'NDI::CapiSample::Protocol::Port']]],
  ['streamid',['StreamId',['../classNDI_1_1CapiSample_1_1Protocol_1_1StreamCommand.html#a69891a2d267d834bad3ac830562618cd',1,'NDI.CapiSample.Protocol.StreamCommand.StreamId()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1StreamPacket.html#af7cdcf494d54360f652ff107a0cc455f',1,'NDI.CapiSample.Protocol.StreamPacket.StreamId()']]]
];
