var searchData=
[
  ['magnetic',['Magnetic',['../namespaceNDI_1_1CapiSample_1_1Data.html#a10c84fdce96b5c4483eba82349bd7503a52432cbd9f9df2483189ce2cb45f8bad',1,'NDI::CapiSample::Data']]],
  ['maintemp',['MainTemp',['../namespaceNDI_1_1CapiSample_1_1Data.html#a096caf66cb8f24696213967ea5e3797fafb12894fdee16b645036befac9a88eb5',1,'NDI::CapiSample::Data']]],
  ['mainvoltage',['MainVoltage',['../namespaceNDI_1_1CapiSample_1_1Data.html#a096caf66cb8f24696213967ea5e3797fabf7e2366207d7808e0cad8e60ccf58d2',1,'NDI::CapiSample::Data']]],
  ['microscopetracker',['MicroscopeTracker',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#ac183d1ac572059b4170e9d113cdfb1d5af852e46cd1795c26100147019d6dd74c',1,'NDI::CapiSample::Protocol']]],
  ['missing',['Missing',['../namespaceNDI_1_1CapiSample_1_1Data.html#a5bdd244c85df22cbcd881d942471a595a2aee0be2678ee90fd327cc186826438e',1,'NDI.CapiSample.Data.Missing()'],['../namespaceNDI_1_1CapiSample_1_1Data.html#a5fe0a5f9b693183ed5c9ca75101d9d2ca2aee0be2678ee90fd327cc186826438e',1,'NDI.CapiSample.Data.Missing()']]]
];
