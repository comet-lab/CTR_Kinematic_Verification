var searchData=
[
  ['markerstatus',['MarkerStatus',['../namespaceNDI_1_1CapiSample_1_1Data.html#a5bdd244c85df22cbcd881d942471a595',1,'NDI::CapiSample::Data']]]
];
