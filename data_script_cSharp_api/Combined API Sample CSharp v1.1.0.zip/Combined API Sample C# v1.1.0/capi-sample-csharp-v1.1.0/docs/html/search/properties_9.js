var searchData=
[
  ['numberofsensors',['NumberOfSensors',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#a8db4bd012a936472c0665790e144dcb7',1,'NDI::CapiSample::Protocol::Port']]]
];
