var searchData=
[
  ['frametype',['FrameType',['../namespaceNDI_1_1CapiSample_1_1Data.html#a10c84fdce96b5c4483eba82349bd7503',1,'NDI::CapiSample::Data']]]
];
