var searchData=
[
  ['write',['Write',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a4e5f909cbc97884d968d635e95de91d4',1,'NDI.CapiSample.Protocol.Capi.Write()'],['../classNDI_1_1CapiSample_1_1Utility_1_1SeekableBufferedStream.html#a18fe047cfa667259e42b6672ec213e12',1,'NDI.CapiSample.Utility.SeekableBufferedStream.Write()']]]
];
