var searchData=
[
  ['seek',['Seek',['../classNDI_1_1CapiSample_1_1Utility_1_1SeekableBufferedStream.html#aa96d1714fe9f892c4992a2065ba3081c',1,'NDI::CapiSample::Utility::SeekableBufferedStream']]],
  ['seekablebufferedstream',['SeekableBufferedStream',['../classNDI_1_1CapiSample_1_1Utility_1_1SeekableBufferedStream.html#ac9fd35d5e508de3d33399ccfefcc2c6a',1,'NDI::CapiSample::Utility::SeekableBufferedStream']]],
  ['send',['Send',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#ad1a06aa1ad3e7ed1d331898555dec11b',1,'NDI.CapiSample.Protocol.Capi.Send(string command, bool expectResponse=true)'],['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a739159121535f8b198245d426d8c4613',1,'NDI.CapiSample.Protocol.Capi.Send(Command command, bool expectResponse=true)']]],
  ['sendbx',['SendBX',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a1cfb78b784f57f04429324fd450e9016',1,'NDI::CapiSample::Protocol::Capi']]],
  ['sendbx2',['SendBX2',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a198f77ff4ee25533c4ab8812af196292',1,'NDI::CapiSample::Protocol::Capi']]],
  ['setbasestream',['SetBaseStream',['../classNDI_1_1CapiSample_1_1Utility_1_1SeekableBufferedStream.html#ac9cba22019b4dce77f8888c3d382ccfd',1,'NDI::CapiSample::Utility::SeekableBufferedStream']]],
  ['setcommunicationparams',['SetCommunicationParams',['../classNDI_1_1CapiSample_1_1CapiSerial.html#a216507477de43d6edfdd4f9268af4a97',1,'NDI::CapiSample::CapiSerial']]],
  ['setlength',['SetLength',['../classNDI_1_1CapiSample_1_1Utility_1_1SeekableBufferedStream.html#a1cd56a5341830f4d9067429ee5e4ea80',1,'NDI::CapiSample::Utility::SeekableBufferedStream']]],
  ['setlogger',['SetLogger',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a43ce313a492646cee5b387c5a16e2a35',1,'NDI::CapiSample::Protocol::Capi']]],
  ['setuserparameter',['SetUserParameter',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#acf6169546031720e22d273a0063347c7',1,'NDI::CapiSample::Protocol::Capi']]],
  ['startstreaming',['StartStreaming',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a41f17af65ebd004d90e755fa21689d22',1,'NDI::CapiSample::Protocol::Capi']]],
  ['stopstreaming',['StopStreaming',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a5e5ee1a5ee73a056206dc0a060a0f784',1,'NDI.CapiSample.Protocol.Capi.StopStreaming(StreamCommand command)'],['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#af39c45fe460d1f0eb73fe8e32110b067',1,'NDI.CapiSample.Protocol.Capi.StopStreaming(string streamId)']]],
  ['streamcommand',['StreamCommand',['../classNDI_1_1CapiSample_1_1Protocol_1_1StreamCommand.html#a05a5022f4a1aba99825bed25365110a5',1,'NDI::CapiSample::Protocol::StreamCommand']]],
  ['streampacket',['StreamPacket',['../classNDI_1_1CapiSample_1_1Protocol_1_1StreamPacket.html#a386b753893ad5fe19368158c1e4b2e4e',1,'NDI::CapiSample::Protocol::StreamPacket']]]
];
