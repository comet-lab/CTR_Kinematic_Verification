var searchData=
[
  ['data2d',['Data2D',['../namespaceNDI_1_1CapiSample_1_1Protocol_1_1GBF.html#a055834992c2b0d090e216654bf2919dea5a509c2245b5389cd6585effd507d0b0',1,'NDI::CapiSample::Protocol::GBF']]],
  ['data3d',['Data3D',['../namespaceNDI_1_1CapiSample_1_1Protocol_1_1GBF.html#a055834992c2b0d090e216654bf2919dea77934ac653c7bbf13b0330bf611d29d2',1,'NDI::CapiSample::Protocol::GBF']]],
  ['data6d',['Data6D',['../namespaceNDI_1_1CapiSample_1_1Protocol_1_1GBF.html#a055834992c2b0d090e216654bf2919deae9a7f2e7231907433777657eb8f10bfd',1,'NDI::CapiSample::Protocol::GBF']]],
  ['databufferlimit',['DataBufferLimit',['../namespaceNDI_1_1CapiSample_1_1Data.html#a673f8d4be756b5c1dc4603c5ffd4818ba39aea5882ac1cf8efb55555e88d6b456',1,'NDI::CapiSample::Data']]],
  ['disabled',['Disabled',['../namespaceNDI_1_1CapiSample_1_1Data.html#a5fe0a5f9b693183ed5c9ca75101d9d2cab9f5c797ebbf55adccdd8539a65a0241',1,'NDI::CapiSample::Data']]],
  ['dummy',['Dummy',['../namespaceNDI_1_1CapiSample_1_1Data.html#a10c84fdce96b5c4483eba82349bd7503abcf036b6f33e182d4705f4f5b1af13ac',1,'NDI::CapiSample::Data']]]
];
