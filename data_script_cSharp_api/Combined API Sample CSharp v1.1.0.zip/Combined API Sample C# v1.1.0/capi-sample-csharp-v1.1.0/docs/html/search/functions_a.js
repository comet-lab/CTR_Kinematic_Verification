var searchData=
[
  ['onnewpacket',['OnNewPacket',['../classNDI_1_1CapiSample_1_1Protocol_1_1StreamCommand.html#a12263092591f213c3ca583e05867684d',1,'NDI::CapiSample::Protocol::StreamCommand']]]
];
