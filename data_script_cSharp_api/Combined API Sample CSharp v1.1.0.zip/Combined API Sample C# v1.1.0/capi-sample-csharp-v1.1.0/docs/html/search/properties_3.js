var searchData=
[
  ['errorcode',['ErrorCode',['../classNDI_1_1CapiSample_1_1Protocol_1_1AsciiPacket.html#a05b87eade6141d94187bc1ccdc32d494',1,'NDI::CapiSample::Protocol::AsciiPacket']]]
];
