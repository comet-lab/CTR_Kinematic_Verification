var searchData=
[
  ['isconnected',['IsConnected',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#ad0d6db5180757f8516cb298d9e689cf8',1,'NDI::CapiSample::Protocol::Capi']]],
  ['istracking',['IsTracking',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#abb60a833526803d844af44e8bbfba2c4',1,'NDI::CapiSample::Protocol::Capi']]],
  ['isvalid',['IsValid',['../classNDI_1_1CapiSample_1_1Protocol_1_1Packet.html#a85802310e7219e1bb6ce5efae2c0d9fe',1,'NDI::CapiSample::Protocol::Packet']]]
];
