var searchData=
[
  ['facenumber',['faceNumber',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#a40b5e0994d9ebf92ff9f7386621ddd2b',1,'NDI::CapiSample::Data::Transform']]],
  ['framenumber',['frameNumber',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#ab94c31acfb70e924af4dd77096269aca',1,'NDI::CapiSample::Data::Tool']]],
  ['framesequenceindex',['frameSequenceIndex',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#ad7f002ed671f06f57ea428bbf4d4f843',1,'NDI::CapiSample::Data::Tool']]],
  ['framestatus',['frameStatus',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a6bf7a24154f5dde72e22ae2213b4f4f2',1,'NDI::CapiSample::Data::Tool']]],
  ['frametype',['frameType',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#aeb446f9493d2862891de4df11b30d26f',1,'NDI::CapiSample::Data::Tool']]]
];
