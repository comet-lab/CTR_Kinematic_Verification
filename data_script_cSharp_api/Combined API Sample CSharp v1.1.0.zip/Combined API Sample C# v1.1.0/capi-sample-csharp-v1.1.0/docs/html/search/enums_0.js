var searchData=
[
  ['bxreplyoptionflags',['BxReplyOptionFlags',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#ab301a755f600f4b3065543d30fd61ff7',1,'NDI::CapiSample::Protocol']]]
];
