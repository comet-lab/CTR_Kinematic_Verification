var searchData=
[
  ['handlestatus',['HandleStatus',['../namespaceNDI_1_1CapiSample_1_1Data.html#a5fe0a5f9b693183ed5c9ca75101d9d2c',1,'NDI::CapiSample::Data']]]
];
