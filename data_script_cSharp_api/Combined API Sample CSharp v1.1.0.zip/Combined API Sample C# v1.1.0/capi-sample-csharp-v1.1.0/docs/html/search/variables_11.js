var searchData=
[
  ['sequenceindex',['sequenceIndex',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a0a9a7100e869eee479f7a2689c59baae',1,'NDI::CapiSample::Protocol::GBF::GbfFrameItem']]],
  ['size',['size',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfComponent.html#ada8127f4cd0d1d0884708f803a9893e3',1,'NDI::CapiSample::Protocol::GBF::GbfComponent']]],
  ['status',['status',['../classNDI_1_1CapiSample_1_1Data_1_1Marker.html#ada904020cc4ef154f9e27a9625845dbf',1,'NDI.CapiSample.Data.Marker.status()'],['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#a177f3e2cdb0b2e9534554e6938db3f2c',1,'NDI.CapiSample.Data.Transform.status()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a00726fb9a8087c143132e4a4fb7dfb94',1,'NDI.CapiSample.Protocol.GBF.GbfFrameItem.status()']]],
  ['status_5fmask_5fcode',['STATUS_MASK_CODE',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#a890c8b99996b01d5e6824caaf76491f9',1,'NDI::CapiSample::Data::Transform']]],
  ['status_5fmask_5fface',['STATUS_MASK_FACE',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#a5f5c54c343f71122a2391afea476867c',1,'NDI::CapiSample::Data::Transform']]],
  ['status_5fmask_5fmissing',['STATUS_MASK_MISSING',['../classNDI_1_1CapiSample_1_1Data_1_1Transform.html#a388a365202993cdb7abbd36dccf531d2',1,'NDI::CapiSample::Data::Transform']]],
  ['subtype',['subType',['../classNDI_1_1CapiSample_1_1Data_1_1SystemAlert.html#a4b4602da8f5574a9dc08592ea3b36707',1,'NDI::CapiSample::Data::SystemAlert']]],
  ['systemalerts',['systemAlerts',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a73d9c5f9740c52afad0dc84cc0aa258d',1,'NDI::CapiSample::Data::Tool']]],
  ['systemstatus',['systemStatus',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a4fc55f405c568153b8f883ee9497470a',1,'NDI::CapiSample::Data::Tool']]]
];
