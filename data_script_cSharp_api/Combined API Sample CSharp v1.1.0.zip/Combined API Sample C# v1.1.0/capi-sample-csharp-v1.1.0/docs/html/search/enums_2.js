var searchData=
[
  ['degreesoffreedom',['DegreesOfFreedom',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#acabd1db1cf3bbd0f57f2d24443b2c40b',1,'NDI::CapiSample::Protocol']]]
];
