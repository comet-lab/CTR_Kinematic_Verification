var searchData=
[
  ['main',['Main',['../classNDI_1_1CapiSampleApplication_1_1Program.html#aafb1ba09de0d683f03ff25f718bc1594',1,'NDI.CapiSampleApplication.Program.Main()'],['../classNDI_1_1CapiSampleStreaming_1_1Program.html#a44264f61c146fd1b452550fc9f306d9a',1,'NDI.CapiSampleStreaming.Program.Main()']]]
];
