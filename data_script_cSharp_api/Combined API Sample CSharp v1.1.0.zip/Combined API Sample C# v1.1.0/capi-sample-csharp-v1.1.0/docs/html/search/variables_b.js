var searchData=
[
  ['markers',['markers',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a0a2d2b0c2f543351c32f32cc8c31654b',1,'NDI.CapiSample.Data.Tool.markers()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfData3D.html#a123af9e21ba758ddcf5d43ae51cb8b90',1,'NDI.CapiSample.Protocol.GBF.GbfData3D.markers()']]]
];
