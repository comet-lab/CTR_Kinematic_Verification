var searchData=
[
  ['gbfcontainer',['GbfContainer',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfContainer.html#a7eb35f46c3100a6e9bcc137651a54100',1,'NDI::CapiSample::Protocol::GBF::GbfContainer']]],
  ['gbfdata3d',['GbfData3D',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfData3D.html#a7f7516881bfb329d9d424b11c49c729c',1,'NDI::CapiSample::Protocol::GBF::GbfData3D']]],
  ['gbfdata6d',['GbfData6D',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfData6D.html#af09e3823a494aec568bea4ba3032382c',1,'NDI::CapiSample::Protocol::GBF::GbfData6D']]],
  ['gbfframe',['GbfFrame',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrame.html#a7b94d0a0d12a7ec738bf717ca668191b',1,'NDI::CapiSample::Protocol::GBF::GbfFrame']]],
  ['gbfframeitem',['GbfFrameItem',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrameItem.html#a77afb25166d0652aae4a33b6388cfd21',1,'NDI::CapiSample::Protocol::GBF::GbfFrameItem']]],
  ['gbfsystemalert',['GbfSystemAlert',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfSystemAlert.html#ab0d67977c9e54192f0319d88b4ca9d4c',1,'NDI::CapiSample::Protocol::GBF::GbfSystemAlert']]],
  ['getapirevision',['GetAPIRevision',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a7b0b1cebebf2ae8e7f51a915db2e0be4',1,'NDI::CapiSample::Protocol::Capi']]],
  ['getavailablecomports',['GetAvailableComPorts',['../classNDI_1_1CapiSample_1_1CapiSerial.html#a4a7e9b975681c060970d647f06773309',1,'NDI::CapiSample::CapiSerial']]],
  ['getconnectioninfo',['GetConnectionInfo',['../classNDI_1_1CapiSample_1_1CapiSerial.html#aeb0f8473111fdbf046f8c0e093abb619',1,'NDI.CapiSample.CapiSerial.GetConnectionInfo()'],['../classNDI_1_1CapiSample_1_1CapiTcp.html#a7add8c6424a8b069db119c7c80fe766e',1,'NDI.CapiSample.CapiTcp.GetConnectionInfo()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a64644c8d9aa1b52da05c70e8b5991ccf',1,'NDI.CapiSample.Protocol.Capi.GetConnectionInfo()']]],
  ['geterrorcode',['GetErrorCode',['../classNDI_1_1CapiSample_1_1Protocol_1_1AsciiPacket.html#a8a61069a9057698391d1616a054e64f2',1,'NDI::CapiSample::Protocol::AsciiPacket']]],
  ['geterrorstring',['GetErrorString',['../classNDI_1_1CapiSample_1_1Protocol_1_1AsciiPacket.html#a324e19b2c86f3f2d7061743c4dbfb25c',1,'NDI.CapiSample.Protocol.AsciiPacket.GetErrorString()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1AsciiPacket.html#a1a8995946a1c9979744802a344fc1703',1,'NDI.CapiSample.Protocol.AsciiPacket.GetErrorString(uint code)']]],
  ['getinfo',['GetInfo',['../classNDI_1_1CapiSample_1_1Protocol_1_1Port.html#a3b2d764675717cdabbf0b4f691eba98a',1,'NDI::CapiSample::Protocol::Port']]],
  ['getip',['GetIP',['../classNDI_1_1CapiSampleApplication_1_1Program.html#acab3415abca6b135f3d296a6bfaff982',1,'NDI.CapiSampleApplication.Program.GetIP()'],['../classNDI_1_1CapiSampleStreaming_1_1Program.html#afc387673b217b557463eabd5759897b8',1,'NDI.CapiSampleStreaming.Program.GetIP()']]],
  ['getlogger',['GetLogger',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a71551a3232a55e93943cd57a57495217',1,'NDI::CapiSample::Protocol::Capi']]],
  ['getpayloadstream',['GetPayloadStream',['../classNDI_1_1CapiSample_1_1Protocol_1_1BinaryPacket.html#a2466003027064d3bac8b8ae518b410ad',1,'NDI::CapiSample::Protocol::BinaryPacket']]],
  ['getrealbaudratevalue',['GetRealBaudRateValue',['../classNDI_1_1CapiSample_1_1CapiSerial.html#ac316a9af12552ae332db0120d2deb600',1,'NDI::CapiSample::CapiSerial']]],
  ['gettoollist',['GetToolList',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfFrame.html#a88603f8cdf5101f66668496ab12dc512',1,'NDI::CapiSample::Protocol::GBF::GbfFrame']]],
  ['getuserparameter',['GetUserParameter',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#ae2946b81f3a58ca6dc3d53528eaee301',1,'NDI::CapiSample::Protocol::Capi']]],
  ['getversion',['GetVersion',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#aa5ab02ddc43d3f4faf12a6cd844dd0af',1,'NDI::CapiSample::Protocol::Capi']]]
];
