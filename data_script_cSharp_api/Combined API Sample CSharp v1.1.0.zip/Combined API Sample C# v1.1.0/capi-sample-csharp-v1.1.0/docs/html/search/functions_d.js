var searchData=
[
  ['read',['Read',['../classNDI_1_1CapiSample_1_1Utility_1_1SeekableBufferedStream.html#aacef3f222f106c81a2c15671d543d168',1,'NDI::CapiSample::Utility::SeekableBufferedStream']]],
  ['reset',['Reset',['../classNDI_1_1CapiSample_1_1CapiSerial.html#a290ec5550e1ceefbbe2a39370ec96b7b',1,'NDI.CapiSample.CapiSerial.Reset()'],['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#a09c8691d435c083b2b1610bc4a035580',1,'NDI.CapiSample.Protocol.Capi.Reset()']]],
  ['run',['Run',['../classNDI_1_1CapiSampleApplication_1_1Program.html#a8eef5f61bf5a73d71cf8e190612383d3',1,'NDI.CapiSampleApplication.Program.Run()'],['../classNDI_1_1CapiSampleStreaming_1_1Program.html#ad7dba7dffec4679a55d90ab21c540ef4',1,'NDI.CapiSampleStreaming.Program.Run()']]]
];
