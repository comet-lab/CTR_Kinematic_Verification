var searchData=
[
  ['nonfatalparameter',['NonFatalParameter',['../namespaceNDI_1_1CapiSample_1_1Data.html#ad8397722b3cff95bce3f02774bc5622eaddc22e688c5c4342a091abbdb165e361',1,'NDI::CapiSample::Data']]],
  ['notenabled',['NotEnabled',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#a74c1492033e40fd4b884f034cfd91740a382542b455122ca37f377b7a66cafc4d',1,'NDI::CapiSample::Protocol']]],
  ['notinit',['NotInit',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#a74c1492033e40fd4b884f034cfd91740a46dbb2fe48fe1beb6a7f2893c6ae56e5',1,'NDI::CapiSample::Protocol']]]
];
