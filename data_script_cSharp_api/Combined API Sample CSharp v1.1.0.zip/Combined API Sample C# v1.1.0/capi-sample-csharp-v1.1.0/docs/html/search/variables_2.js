var searchData=
[
  ['buffer_5fsize',['BUFFER_SIZE',['../classNDI_1_1CapiSample_1_1Protocol_1_1Capi.html#ac9dc866542973ca3c019c637f6810af5',1,'NDI::CapiSample::Protocol::Capi']]],
  ['buttons',['buttons',['../classNDI_1_1CapiSample_1_1Data_1_1Tool.html#a6f77b8bc6dfa98109d25f8f4e5a3bab1',1,'NDI::CapiSample::Data::Tool']]]
];
