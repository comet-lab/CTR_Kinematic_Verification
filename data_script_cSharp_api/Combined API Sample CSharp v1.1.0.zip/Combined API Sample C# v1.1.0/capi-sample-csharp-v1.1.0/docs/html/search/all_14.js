var searchData=
[
  ['valid',['Valid',['../namespaceNDI_1_1CapiSample_1_1Data.html#a5fe0a5f9b693183ed5c9ca75101d9d2ca3ac705f2acd51a4613f9188c05c91d0d',1,'NDI::CapiSample::Data']]],
  ['vector3',['Vector3',['../classNDI_1_1CapiSample_1_1Data_1_1Vector3.html',1,'NDI::CapiSample::Data']]],
  ['vector3',['Vector3',['../classNDI_1_1CapiSample_1_1Data_1_1Vector3.html#a2d8087cb408092c620b80d95e4be2fb3',1,'NDI.CapiSample.Data.Vector3.Vector3()'],['../classNDI_1_1CapiSample_1_1Data_1_1Vector3.html#a9991cd512893917ecc7ccf68e15f898a',1,'NDI.CapiSample.Data.Vector3.Vector3(double x, double y, double z)']]],
  ['vector3_2ecs',['Vector3.cs',['../Vector3_8cs.html',1,'']]]
];
