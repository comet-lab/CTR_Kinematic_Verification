var searchData=
[
  ['gbfversion',['gbfVersion',['../classNDI_1_1CapiSample_1_1Protocol_1_1GBF_1_1GbfContainer.html#af6fd54b257a65f8228bc6dc6742f255e',1,'NDI::CapiSample::Protocol::GBF::GbfContainer']]]
];
