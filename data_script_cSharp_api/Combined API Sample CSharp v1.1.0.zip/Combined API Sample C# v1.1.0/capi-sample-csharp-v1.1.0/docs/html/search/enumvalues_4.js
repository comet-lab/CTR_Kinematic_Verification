var searchData=
[
  ['enabled',['Enabled',['../namespaceNDI_1_1CapiSample_1_1Data.html#a673f8d4be756b5c1dc4603c5ffd4818ba00d23a76e43b46dae9ec7aa9dcbebb32',1,'NDI.CapiSample.Data.Enabled()'],['../namespaceNDI_1_1CapiSample_1_1Protocol.html#a74c1492033e40fd4b884f034cfd91740a00d23a76e43b46dae9ec7aa9dcbebb32',1,'NDI.CapiSample.Protocol.Enabled()'],['../namespaceNDI_1_1CapiSample_1_1Protocol.html#a7e8b2a69ccaed8ab165011ca079257c7a00d23a76e43b46dae9ec7aa9dcbebb32',1,'NDI.CapiSample.Protocol.Enabled()']]],
  ['event',['Event',['../namespaceNDI_1_1CapiSample_1_1Data.html#a7f89ff5430b16c54780c655ae2c04983aa4ecfc70574394990cf17bd83df499f7',1,'NDI::CapiSample::Data']]]
];
