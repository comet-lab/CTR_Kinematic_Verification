var searchData=
[
  ['length',['Length',['../classNDI_1_1CapiSample_1_1Utility_1_1SeekableBufferedStream.html#ab85c8d94f4c24c40061f36366f6cfadd',1,'NDI::CapiSample::Utility::SeekableBufferedStream']]]
];
