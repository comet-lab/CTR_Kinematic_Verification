var searchData=
[
  ['background',['Background',['../namespaceNDI_1_1CapiSample_1_1Data.html#a10c84fdce96b5c4483eba82349bd7503aa9ded1e5ce5d75814730bb4caaf49419',1,'NDI::CapiSample::Data']]],
  ['badtransformfit',['BadTransformFit',['../namespaceNDI_1_1CapiSample_1_1Data.html#a673f8d4be756b5c1dc4603c5ffd4818baed9df37e016f4a4223bd212696fafe3c',1,'NDI::CapiSample::Data']]],
  ['batterylow',['BatteryLow',['../namespaceNDI_1_1CapiSample_1_1Data.html#ad8397722b3cff95bce3f02774bc5622ea2e7b40a09172a70f94dbde6e2bfb9ea8',1,'NDI::CapiSample::Data']]],
  ['baud115200',['Baud115200',['../namespaceNDI_1_1CapiSample.html#a33fb1ccdd9c66e103147587cced28ea1a0c8765e6a63fd04590756e2d3150ce68',1,'NDI::CapiSample']]],
  ['baud1228739',['Baud1228739',['../namespaceNDI_1_1CapiSample.html#a33fb1ccdd9c66e103147587cced28ea1a878dfd700bea3f23eb41558ebc87b148',1,'NDI::CapiSample']]],
  ['baud14400',['Baud14400',['../namespaceNDI_1_1CapiSample.html#a33fb1ccdd9c66e103147587cced28ea1ad456495b5931a3a12bcba88f576f7d05',1,'NDI::CapiSample']]],
  ['baud19200',['Baud19200',['../namespaceNDI_1_1CapiSample.html#a33fb1ccdd9c66e103147587cced28ea1a7de3ea344161b0f8c2891f7ccea663b2',1,'NDI::CapiSample']]],
  ['baud38400',['Baud38400',['../namespaceNDI_1_1CapiSample.html#a33fb1ccdd9c66e103147587cced28ea1a43a58048d19a2c12113121c54a496e81',1,'NDI::CapiSample']]],
  ['baud57600',['Baud57600',['../namespaceNDI_1_1CapiSample.html#a33fb1ccdd9c66e103147587cced28ea1a5df0ba18de3712cd4d8689f5d3f8e1fa',1,'NDI::CapiSample']]],
  ['baud921600',['Baud921600',['../namespaceNDI_1_1CapiSample.html#a33fb1ccdd9c66e103147587cced28ea1a813ced08ac90c0ccdc6ac619cd327479',1,'NDI::CapiSample']]],
  ['baud9600',['Baud9600',['../namespaceNDI_1_1CapiSample.html#a33fb1ccdd9c66e103147587cced28ea1a8e072f20a097851ad5fbbf16e3026efe',1,'NDI::CapiSample']]],
  ['bumpdetected',['BumpDetected',['../namespaceNDI_1_1CapiSample_1_1Data.html#ad8397722b3cff95bce3f02774bc5622eae8f969720a06fd9bd112569412186257',1,'NDI::CapiSample::Data']]],
  ['button1d',['Button1D',['../namespaceNDI_1_1CapiSample_1_1Protocol_1_1GBF.html#a055834992c2b0d090e216654bf2919dea5893afcfe50dd58ec43543d0482b8fd2',1,'NDI::CapiSample::Protocol::GBF']]],
  ['buttonbox',['ButtonBox',['../namespaceNDI_1_1CapiSample_1_1Protocol.html#ac183d1ac572059b4170e9d113cdfb1d5a047d2f21415ad01e4047a5dc65725e46',1,'NDI::CapiSample::Protocol']]]
];
