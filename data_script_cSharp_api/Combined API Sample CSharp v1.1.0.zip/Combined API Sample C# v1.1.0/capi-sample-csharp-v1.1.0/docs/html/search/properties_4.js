var searchData=
[
  ['framecountdivisor',['FrameCountDivisor',['../classNDI_1_1CapiSample_1_1Protocol_1_1StreamCommand.html#a41845df5ea082704bfe69ea53cf2301e',1,'NDI::CapiSample::Protocol::StreamCommand']]]
];
